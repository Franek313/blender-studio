bl_info = {
    "name": "BlenderStudio VideoEditor",
    "blender": (4, 4, 0),
    "category": "Video",
}

def register():
    print("Hello World, I'm Video Editor!")

def unregister():
    print("Goodbye World! I'm Video Editor")